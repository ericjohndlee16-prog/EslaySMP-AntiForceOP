# EslaySMP AntiForceOP

**Target:** Paper 1.21.11 · Java 21  
**Plugin display name:** `EslaySMP-AntiForceOP`

This starter plugin blocks configured protected command roots when ordinary players try to run them.

## Build
Push this project to a GitHub repository. Open **Actions**, run **Build AntiForceOP**, and download the `AntiForceOP` artifact from a successful workflow run. The JAR is inside that artifact.

## Install
1. Stop your Paper server.
2. Upload the built JAR into the server's `plugins` folder.
3. Start the server once to generate `plugins/EslaySMP-AntiForceOP/config.yml`.
4. Add trusted staff UUIDs to `trusted-uuids`.
5. Restart the server.

## Important limitations
This protects against configured player-issued command attempts. It cannot stop a malicious plugin or server exploit that grants OP through the server API, or someone who already has hosting-panel, console, file, or server-owner access. Keep Paper and plugins updated, use least-privilege LuckPerms groups, remove unknown plugins, and secure hosting credentials. Test on a copy before using it on your live SMP.

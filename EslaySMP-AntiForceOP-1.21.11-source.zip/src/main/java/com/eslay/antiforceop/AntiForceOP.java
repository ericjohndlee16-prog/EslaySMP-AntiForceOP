package com.eslay.antiforceop;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class AntiForceOP extends JavaPlugin implements Listener {
    private final Set<UUID> trusted = new HashSet<>();
    private Set<String> blockedRoots = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AntiForceOP enabled. Trusted UUIDs: " + trusted.size());
    }

    private void loadSettings() {
        reloadConfig();
        trusted.clear();
        for (String value : getConfig().getStringList("trusted-uuids")) {
            try {
                trusted.add(UUID.fromString(value));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Ignoring invalid UUID in config.yml: " + value);
            }
        }
        blockedRoots = new HashSet<>();
        for (String root : getConfig().getStringList("blocked-command-roots")) {
            blockedRoots.add(root.toLowerCase(Locale.ROOT));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();

        // Trusted UUIDs and explicitly permissioned staff can use protected commands.
        if (trusted.contains(player.getUniqueId()) || player.hasPermission("antiforceop.bypass")) {
            return;
        }

        String message = event.getMessage().trim();
        if (!message.startsWith("/")) return;

        String commandLine = message.substring(1).trim().toLowerCase(Locale.ROOT);
        if (commandLine.isEmpty()) return;

        String root = commandLine.split("\\s+", 2)[0];
        // Strip a namespace if one is present, while also checking the full root.
        String unnamespaced = root.contains(":")
                ? root.substring(root.indexOf(':') + 1)
                : root;

        if (blockedRoots.contains(root) || blockedRoots.contains(unnamespaced)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "That command is protected by AntiForceOP.");
            alertStaff(player, message);
            getLogger().warning("Blocked protected command from " + player.getName()
                    + " (" + player.getUniqueId() + "): " + message);
        }
    }

    private void alertStaff(Player actor, String command) {
        if (!getConfig().getBoolean("notify-staff", true)) return;
        String alert = ChatColor.DARK_RED + "[AntiForceOP] "
                + ChatColor.RED + actor.getName()
                + " attempted a protected command: " + command;
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.hasPermission("antiforceop.notify")) {
                online.sendMessage(alert);
            }
        }
        CommandSender console = Bukkit.getConsoleSender();
        console.sendMessage("[AntiForceOP] Blocked protected command from "
                + actor.getName() + ": " + command);
    }
}
